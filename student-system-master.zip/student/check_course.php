<?php
header("content-type:text/html;charset:utf-8");

$con = mysqli_connect('localhost','root','1234');
mysqli_select_db($con,'y1');
mysqli_query($con,'set names utf8');

$cookie = $_COOKIE['name'];

$sql = "select Cname from selection where Sname='$cookie'";
$sqls = mysqli_query($con,$sql);


echo <<<Eof
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <script type="text/javascript" src="js/jquery-3.1.1.js"></script>
    <script type="text/javascript" src="js/bootstrap.min.js"></script>

   
Eof;

while($row=mysqli_fetch_assoc($sqls)){
	
	$sql_t ="select Tname from teacher where Tcourse='{$row['Cname']}'";
	$sqls_t = mysqli_query($con,$sql_t);
	$rows = mysqli_fetch_assoc($sqls_t);
	echo "<h4 class='text-primary'>所选课程：<span style='color:red'>{$row['Cname']}</span> ------ 老师：<span style='color:red'>{$rows['Tname']}</span></h4>";
	}

mysqli_close($con);
?>