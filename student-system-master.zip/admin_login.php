<?php
header("content-type:text/html;charset=utf-8");
$con = mysqli_connect('localhost','root','1234');
mysqli_select_db($con,'y1');
mysqli_query($con,"set names utf8");

$name = $_POST['name'];  
$password = MD5($_POST['password']); 


$sql = mysqli_query($con,"select Aid from admin where name='$name' and password='$password' limit 1");
$sqls = mysqli_fetch_array($sql);
if($sqls){
	setcookie('name',$name,time()+3600);
	echo "<script>location='admin.php';</script>";
	}else {
		echo "<script>alert('登录失败。');history.go(-1);</script>";
		}

mysqli_close($con);
?>