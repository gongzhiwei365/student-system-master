<?php

header("content-type:text/html;charset=utf-8");

$con = mysqli_connect('localhost','root','1234');
mysqli_select_db($con,'y1');
mysqli_query($con,"set names utf8");

$cookie = $_COOKIE["num"];

$Cname = mysqli_query($con,"select Tcourse from teacher where Tnum=$cookie");
$t = mysqli_fetch_assoc($Cname);

$Cnum = mysqli_query($con,"select Cnum from course where Cname='{$t['Tcourse']}'");
$cnum=mysqli_fetch_assoc($Cnum);

$ts = $t['Tcourse'];
 
  $sql = "select Sname from selection where Cname='{$ts}'";
  $sqls = mysqli_query($con,$sql);  //找到所选课程的学生名字
  
echo <<<Eof
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css" >
	<script src="js/jquery-3.1.1.js"></script>
	<script type="text/javascript" src="js/bootstrap.min.js"></script>
    <center><h3 class="text-info" style="margin-left:-80px;">选课学生({$cnum['Cnum']}人)</h3></center>
    <table class="table table-bordered table-hover"><tr><td>学生名</td><td>性别</td><td>学号</td><td>成绩</td></tr>
    
Eof;
  
  while($row=mysqli_fetch_assoc($sqls)){
     $row_name = $row['Sname'];
     $res = mysqli_query($con,"select * from student where Sname='$row_name'");
     $rows = mysqli_fetch_assoc($res);
     $sc = mysqli_query($con,"select grade from grade where Sname='$row_name'");
     $scs = mysqli_fetch_assoc($sc);
     echo "<tr>";
     echo "<td>$row_name</td>";
     echo "<td>{$rows['Ssex']}</td>";
     echo "<td>{$rows['Snum']}</td>";
     echo "<td>{$scs['grade']}</td>";
     echo "</tr>";
  }
  
  echo "</table>";


#mysqli_free_result($result);//释放结果资源
mysqli_close($con); //关闭数据库连接
?>