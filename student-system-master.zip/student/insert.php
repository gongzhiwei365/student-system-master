<?php
header("content-type:text/html;charset=utf-8");

$con = mysqli_connect('localhost','root','1234');
mysqli_select_db($con,'y1');
mysqli_query($con,"set names utf8");

$name = $_GET['Cname'];
$cookie = $_COOKIE['name'];
//查询多少个

$tot = "select Cname from selection where Sname='$cookie' and Cname='$name'";
$tots = mysqli_num_rows(mysqli_query($con,$tot));
if($tots<2){
	if($tots==0){
		$sele = "insert into selection(Sname,Cname) values('$cookie','$name')";
        $select = mysqli_query($con,$sele);
        echo "<script>alert('选课成功！');history.go(-1);</script>";
		}else if($tots==1){
	        echo "<script>alert('已选该课程！');history.go(-1);</script>";
//	        $if = mysqli_query($con,"select Cname from selection where Sname='$cookie'");  // cookie 的所有课程
//            mysqli_data_seek($if,0);
//	        $ifs = mysqli_fetch_assoc($if);
//	        if($ifs['Cname']==$name){
//	            echo "<script>alert('已选该课程！');history.go(-1);</script>";
//	          } else{$sele = "insert into selection(Sname,Cname) values('$cookie','$name')";
//                     $select = mysqli_query($con,$sele);
//                     echo "<script>alert('选课成功！');history.go(-1);</script>";}
		 }  
	   
}else{
	echo "<script>alert('当前账户此门选课数据异常，超出限制！');history.go(-1);</script>";
	}



mysqli_close($con);
?>