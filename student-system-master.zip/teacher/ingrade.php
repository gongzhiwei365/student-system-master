<?php
header("content-type:text/html;charset=utf-8");
$con = mysqli_connect('localhost','root','1234');
mysqli_select_db($con,"y1");
mysqli_query($con,"set names utf8");

$cookie = $_COOKIE['name'];
$num = $_POST['snum'];
$score = $_POST['score'];
$name = $_POST['sname'];

$rs = mysqli_query($con,"select Tcourse from teacher where Tname='$cookie'"); //查询该老师所教课程
$rss = mysqli_fetch_assoc($rs);
$Cname = $rss['Tcourse'];

$sc = mysqli_query($con,"select grade from grade where Snum='$num'");  //查询该学生之前有无成绩
$scs = mysqli_fetch_assoc($sc);

if(!$scs['grade']){
	$sql = mysqli_query($con,"insert into grade(Sname,Cname,grade,Snum) values('$name','$Cname',$score,$num)");
	 echo "<script>alert('成绩录入成功！');location='../teacher.php';</script>";
	}else{
		echo "<script>alert('该学生已有成绩。');history.go(-1);</script>";
		}


mysqli_close($con);
?>