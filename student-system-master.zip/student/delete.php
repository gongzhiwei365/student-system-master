<?php
header("content-type:text/html;charset=utf-8");

$con = mysqli_connect('localhost','root','1234');
mysqli_select_db($con,'y1');
mysqli_query($con,"set names utf8");

$name = $_GET['Cname'];
$cookie = $_COOKIE['name'];

$sql = "select Sname,Cname from selection where Sname='$cookie' and Cname='$name'";
$sqls = mysqli_query($con,$sql);
if(mysqli_num_rows($sqls)!=0){
   $del = "delete from selection where Cname='$name' and Sname='$cookie'";
   $dels = mysqli_query($con,$del);
   echo "<script>alert('退选成功！');history.go(-1);</script>";
}else{
	echo "<script>alert('退选失败，无此课程。');history.go(-1);</script>";
	}
	
mysqli_close($con);
?>