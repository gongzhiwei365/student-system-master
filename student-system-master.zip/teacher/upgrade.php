<?php
header("content-type:text/html;charset=utf-8");
$con = mysqli_connect('localhost','root','1234');
mysqli_select_db($con,"y1");
mysqli_query($con,"set names utf8");

$cookie = $_COOKIE['name'];
$name = $_POST['name'];
$score = $_POST['score'];
$num = $_POST['snum'];

$rs = mysqli_query($con,"select Tcourse from teacher where Tname='$cookie'"); //查询该老师所教课程
$rss = mysqli_fetch_assoc($rs);
$Cname = $rss['Tcourse'];

$se = mysqli_query($con,"select grade from grade where Snum=$num");
$ses = mysqli_fetch_assoc($se);
if($ses['grade']){
	$update = mysqli_query($con,"update grade set grade=$score where Snum=$num");
	echo "<script>alert('成绩修改成功！');location='../teacher.php';</script>";
	}else{
		echo "<script>alert('该学生并没有成绩。');history.go(-1);</script>";
		}

#mysqli_free_result($result);//释放结果资源
mysqli_close($con); //关闭数据库连接
?>