<?php
header("content-type:text/html;charset=utf-8");
$con =mysqli_connect('localhost','root','1234');
mysqli_select_db($con,'y1');
mysqli_query($con,'set names utf8');

$Sid=$_POST['sid'];
$name=$_POST['sname'];
$sex=$_POST['ssex'];
$num=$_POST['snum'];

$sql="update student set Sname='{$name}',Ssex='{$sex}',Snum='{$num}' where Sid={$Sid}";
$rst=mysqli_query($con,$sql);
if($rst){
	echo "<script>alert('修改成功！');location='../admin.php';</script>";
	}else{
		echo "<script>alert('修改失败。');history.go(-1);</script>";
		}
mysqli_close($con);
?>