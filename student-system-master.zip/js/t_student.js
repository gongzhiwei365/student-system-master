
$(document).ready(function(){
	
$('button').popover();
});