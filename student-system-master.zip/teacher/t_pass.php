<?php
$con = mysqli_connect('localhost','root','1234');
mysqli_select_db($con,"y1");
mysqli_query($con,"set names utf8");

$cookie = $_COOKIE['num'];
$newpass = MD5($_POST['pass']);

$sql="update teacher set pass='$newpass' where Tnum=$cookie";
$update=mysqli_query($con,$sql);
echo "<script>alert('密码修改成功！请重新登录');location='../logoff.php';</script>";



?>