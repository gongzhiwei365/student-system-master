<?php
header("content-type:text/html;charset=utf-8");
$con =mysqli_connect('localhost','root','1234');
mysqli_select_db($con,'y1');
mysqli_query($con,'set names utf8');

$Tid=$_POST['tid'];
$name=$_POST['tname'];
$sex=$_POST['tsex'];
$course=$_POST['tcourse'];
$num=$_POST['tnum'];

$sql="update teacher set Tname='{$name}',Tsex='{$sex}',Tcourse='{$course}',Tnum='{$num}' where Tid={$Tid}";
$rst=mysqli_query($con,$sql);
if($rst){
	echo "<script>alert('修改成功！');location='../admin.php';</script>";
	}else{
		echo "<script>alert('修改失败。');history.go(-1);</script>";
		}
mysqli_close($con);
?>