<?php
header("content-type:text/html;charset=utf-8");
$con = mysqli_connect('localhost','root','1234');
mysqli_select_db($con,'y1');
mysqli_query($con,"set names utf8");

$pass = MD5($_POST['pass']);
$num = $_POST['snum'];

$sql = "select Sname,Snum from student where pass='$pass' and Snum=$num";
$sqls = mysqli_query($con,$sql);
$result = mysqli_fetch_assoc($sqls);
$name = $result['Sname'];
$snum = $result['Snum'];

if($result){
	setcookie('name',$name,time()+3600);
    setcookie('num',$snum,time()+3600);
    echo "<script>location='student.php'</script>";	
	}else {
		echo "<script>alert('登录失败！');history.go(-1);</script>";
		}

#mysqli_free_result($result);//释放结果资源
mysqli_close($con); //关闭数据库连接
?>