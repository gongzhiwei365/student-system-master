<?php
header("content-type:text/html;charset=utf-8");
$con = mysqli_connect('localhost','root','1234');
mysqli_select_db($con,'y1');
mysqli_query($con,"set names utf8");

$pass = MD5($_POST['pass']);
$num = $_POST['tnum'];

$sql = "select Tname,Tnum from teacher where pass='$pass' and Tnum=$num";
$sqls = mysqli_query($con,$sql);
$result = mysqli_fetch_assoc($sqls);
$name = $result['Tname'];
$tnum = $result['Tnum'];

if($result){
	setcookie('name',$name,time()+3600);
    setcookie('num',$tnum,time()+3600);
    echo "<script>location='teacher.php'</script>";	
	}else {
		echo "<script>alert('登录失败！');history.go(-1)</script>";
		}


#mysqli_free_result($result);//释放结果资源
mysqli_close($con); //关闭数据库连接
?>