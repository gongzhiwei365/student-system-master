<?php 
header("content-type:text/html;charset=utf-8");
$con = mysqli_connect('localhost','root','1234');   //连接数据库
mysqli_select_db($con,'y1');   //选择y1数据库
mysqli_query($con,"set names utf8");  //设置字符集

$name = $_POST['tname'];
$sex = $_POST['tsex'];
$course = $_POST['tcourse'];
$num = $_POST['tnum'];
$id = mysqli_query($con,"select count(*) from teacher");
$ids = mysqli_fetch_row($id);
$Tid = $ids[0]+1;
$sql = mysqli_query($con,"insert into teacher(Tid,Tname,Tsex,Tcourse,Tnum,pass) values($Tid,'$name','$sex','$course',$num,MD5($num))");
if($sql){
echo "<script>alert('老师添加成功！');history.go(-1);</script>";
}else{ echo "<script>alert('老师添加失败。');history.go(-1);</script>";}
mysqli_close($con);
?>
