<?php
header("content-type:text/html;charset=utf-8");
$con=mysqli_connect('localhost','root','1234');
mysqli_select_db($con,'y1');
mysqli_query($con,'set names utf8');

$sql="delete from teacher where Tid={$_GET['Tid']}";
$rst=mysqli_query($con,$sql);

if($rst){
	echo "<script>alert('删除成功！');location='../admin.php';</script>";
	}else{
		echo "<script>alert('删除失败');history.go(-1);</script>";
		}

mysqli_close($con);
?>